# git-playground

A mini-repo that has complicated history. Useful for testing git integrations.
